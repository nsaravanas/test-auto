package api.endPoints;

public class Routes {

	public static String baseUrl= "https://petstore.swagger.io/";
	public static String postUrl=baseUrl+"v2/user";
	public static String getUrl=baseUrl+"v2/user/{username}";
	public static String updateUrl=baseUrl+"v2/user/{username}";
	public static String deleteUrl=baseUrl+"v2/user/{username}";
	
}
